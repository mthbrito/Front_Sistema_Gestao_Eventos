import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthProvider";
import { PrivateRoute } from "./components/PrivateRoute";
import Login from "./pages/Login";
import Cadastro from "./pages/Cadastro";
import Dashboard from "./pages/dashboard";

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* pública */}
          <Route path="/login" element={<Login />} />
          <Route path="/cadastro" element={<Cadastro />} />

          {/* protegidas */}
          <Route element={<PrivateRoute />}>
            {/* adicione as páginas aqui conforme for criando */}
            <Route path="/dashboard" element={<Dashboard />} />
            {/* <Route path="/eventos"   element={<EventosList />} /> */}
          </Route>

          {/* qualquer rota desconhecida cai no login */}
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
